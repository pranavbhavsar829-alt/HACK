from flask import Flask, render_template_string, jsonify
import json
import os
import time

app = Flask(__name__)
DASHBOARD_FILE = 'dashboard_data.json'

# --- PERSISTENT MEMORY STORAGE ---
# This list will hold ALL history as long as this script runs.
# It prevents data loss even if the bot overwrites the JSON file.
GLOBAL_HISTORY = []

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TITAN GOD MODE (FULL HISTORY)</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700;800&display=swap');
        
        :root {
            --bg: #000000;
            --card-bg: #0a0a0a;
            --text: #ffffff;
            --win: #00ff41;
            --loss: #ff0055;
            --wait: #00ccff;
            --border: #222;
        }

        body {
            background-color: var(--bg);
            color: var(--text);
            font-family: 'JetBrains Mono', monospace;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }

        .main-wrapper {
            width: 100%;
            max-width: 550px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .card {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0,0,0,0.6);
            position: relative;
        }

        /* CONTROLS */
        .control-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .btn-reset {
            background: #222;
            color: #fff;
            border: 1px solid #444;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 11px;
            font-weight: bold;
            transition: 0.2s;
        }
        .btn-reset:hover { background: #fff; color: #000; }

        .stats-grid {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 10px;
            padding: 15px;
            background: #0f0f0f;
            border: 1px solid #222;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .stat-box span { font-size: 10px; color: #666; }
        .stat-val { font-size: 20px; font-weight: 800; display: block; margin-top: 5px;}
        .c-win { color: var(--win); }
        .c-loss { color: var(--loss); }

        .header-title { font-size: 10px; color: #444; letter-spacing: 4px; margin-bottom: 5px; }
        .period-display { font-size: 14px; color: #888; margin-bottom: 5px; }
        
        .prediction-box {
            font-size: 64px;
            font-weight: 900;
            margin: 10px 0;
            text-transform: uppercase;
            line-height: 1;
        }
        .res-big { color: var(--win); text-shadow: 0 0 30px rgba(0, 255, 65, 0.2); }
        .res-small { color: var(--loss); text-shadow: 0 0 30px rgba(255, 0, 85, 0.2); }
        .res-wait { color: #333; }

        .copy-area { text-align: left; margin-top: 10px; }
        .copy-label { font-size: 10px; color: #666; margin-bottom: 5px; display: block; font-weight: bold; }
        
        textarea {
            width: 100%;
            background: #000;
            border: 1px solid #333;
            color: #ccc;
            font-family: 'JetBrains Mono', monospace;
            font-size: 12px;
            padding: 15px;
            border-radius: 8px;
            resize: none;
            box-sizing: border-box; 
            margin-bottom: 10px;
            white-space: pre;
            overflow-x: hidden;
            line-height: 1.6;
        }

        .btn-copy {
            background: var(--win);
            color: #000;
            border: none;
            padding: 15px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 900;
            width: 100%;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: 0.2s;
        }
        .btn-copy:hover { opacity: 0.9; transform: scale(1.02); }

    </style>
</head>
<body>

    <div class="main-wrapper">
        <div class="card">
            <div class="control-bar">
                <span style="font-size:12px; font-weight:bold; color:#fff;">SESSION STATS</span>
                <button class="btn-reset" onclick="resetSession()">🔄 START NEW</button>
            </div>
            <div class="stats-grid">
                <div class="stat-box">
                    <span>WINS</span>
                    <span class="stat-val c-win" id="total-wins">0</span>
                </div>
                <div class="stat-box">
                    <span>LOSS</span>
                    <span class="stat-val c-loss" id="total-loss">0</span>
                </div>
                <div class="stat-box">
                    <span>ACCURACY</span>
                    <span class="stat-val" id="win-rate">0%</span>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="header-title">TITAN V4 // PERSISTENT ENGINE</div>
            <div class="period-display" id="period">LOADING...</div>
            <div id="prediction" class="prediction-box res-wait">---</div>
            <div style="font-size:10px; color:#555; margin-top:5px;" id="status-text">WAITING FOR SIGNAL</div>
        </div>

        <div class="card">
            <div class="copy-area">
                <span class="copy-label">TELEGRAM BOLD GENERATOR</span>
                <textarea id="list-box" style="height: 400px;" readonly></textarea>
                <button class="btn-copy" onclick="copyBox()">COPY BOLD LIST</button>
            </div>
        </div>
    </div>

    <script>
        let startPeriod = 0; 

        function resetSession() {
            const currentText = document.getElementById('period').innerText;
            const currentNum = currentText.replace(/\D/g, ''); 
            if(currentNum) {
                startPeriod = Number(currentNum);
                document.getElementById('total-wins').innerText = "0";
                document.getElementById('total-loss').innerText = "0";
                document.getElementById('win-rate').innerText = "0%";
                updateData(); 
            }
        }

        function updateData() {
            fetch('/data')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('period').innerText = "PERIOD: " + data.period;
                    document.getElementById('status-text').innerText = data.status_text || 'ACTIVE';

                    const predEl = document.getElementById('prediction');
                    predEl.innerText = data.prediction;
                    predEl.className = 'prediction-box'; 
                    if (data.prediction === 'BIG') predEl.classList.add('res-big');
                    else if (data.prediction === 'SMALL') predEl.classList.add('res-small');
                    else predEl.classList.add('res-wait');

                    processHistory(data);
                })
                .catch(err => console.log(err));
        }

        function processHistory(data) {
            let history = data.history || [];
            // Sort: Oldest -> Newest
            history.sort((a, b) => Number(a.period) - Number(b.period));

            let wins = 0;
            let losses = 0;
            let outputText = "🐍 3 LEVEL PYTHON SCRIPT 🐍\\n\\n"; 

            history.forEach(item => {
                // Filter by Session Start
                if (Number(item.period) < startPeriod && startPeriod !== 0) return;
                // IGNORE SKIPS
                if (item.result === 'SKIP') return; 

                if (item.result === 'WIN' || item.result === 'LOSS') {
                    if (item.result === 'WIN') wins++;
                    if (item.result === 'LOSS') losses++;

                    let shortPeriod = item.period.toString().slice(-3);
                    let predPadded = item.pred.padEnd(6, ' '); 
                    let resIcon = item.result === 'WIN' ? 'WIN ✅' : 'LOSS ❌';
                    outputText += `${shortPeriod}  ${predPadded}  ${resIcon}\\n`;
                }
            });

            // REAL TIME PENDING (Use global data period)
            const currentPeriod = data.period;
            const currentPred = data.prediction;
            
            // Check if current is already finished in history
            const alreadyInHistory = history.some(h => h.period == currentPeriod);
            
            if (!alreadyInHistory && currentPeriod !== "---" && currentPred !== "WAITING") {
                let shortPeriod = currentPeriod.toString().slice(-3);
                let predPadded = currentPred.padEnd(6, ' ');
                outputText += `${shortPeriod}  ${predPadded}  WAITING ⏳\\n`;
            }

            // UPDATE UI
            document.getElementById('total-wins').innerText = wins;
            document.getElementById('total-loss').innerText = losses;
            let total = wins + losses;
            let rate = total === 0 ? 0 : Math.round((wins / total) * 100);
            document.getElementById('win-rate').innerText = rate + "%";

            // Update Text Box
            const box = document.getElementById('list-box');
            if (box.value !== outputText) {
                box.value = outputText;
                box.scrollTop = box.scrollHeight; 
            }
        }

        function toBold(text) {
            const map = {
                '0': '𝟎', '1': '𝟏', '2': '𝟐', '3': '𝟑', '4': '𝟒', '5': '𝟓', '6': '𝟔', '7': '𝟕', '8': '𝟖', '9': '𝟗',
                'A': '𝐀', 'B': '𝐁', 'C': '𝐂', 'D': '𝐃', 'E': '𝐄', 'F': '𝐅', 'G': '𝐆', 'H': '𝐇', 'I': '𝐈', 'J': '𝐉', 'K': '𝐊', 'L': '𝐋', 'M': '𝐌', 'N': '𝐍', 'O': '𝐎', 'P': '𝐏', 'Q': '𝐐', 'R': '𝐑', 'S': '𝐒', 'T': '𝐓', 'U': '𝐔', 'V': '𝐕', 'W': '𝐖', 'X': '𝐗', 'Y': '𝐘', 'Z': '𝐙',
                'a': '𝐚', 'b': '𝐛', 'c': '𝐜', 'd': '𝐝', 'e': '𝐞', 'f': '𝐟', 'g': '𝐠', 'h': '𝐡', 'i': '𝐢', 'j': '𝐣', 'k': '𝐤', 'l': '𝐥', 'm': '𝐦', 'n': '𝐧', 'o': '𝐨', 'p': '𝐩', 'q': '𝐪', 'r': '𝐫', 's': '𝐬', 't': '𝐭', 'u': '𝐮', 'v': '𝐯', 'w': '𝐰', 'x': '𝐱', 'y': '𝐲', 'z': '𝐳'
            };
            return text.split('').map(char => map[char] || char).join('');
        }

        function copyBox() {
            const box = document.getElementById("list-box");
            const boldText = toBold(box.value);
            navigator.clipboard.writeText(boldText).then(() => {
                const btn = document.querySelector('.btn-copy');
                const btnOriginalText = btn.innerText;
                btn.innerText = "COPIED BOLD!";
                setTimeout(() => btn.innerText = btnOriginalText, 2000);
            });
        }

        setInterval(updateData, 1000); 
    </script>
</body>
</html>
"""

# --- BACKEND LOGIC: HISTORY MERGER ---
@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/data')
def get_data():
    global GLOBAL_HISTORY
    
    # 1. Default Data
    response_data = {
        "period": "---", 
        "prediction": "WAITING", 
        "history": GLOBAL_HISTORY, # Start with what we already know
        "status_text": "IDLE"
    }

    try:
        if os.path.exists(DASHBOARD_FILE):
            with open(DASHBOARD_FILE, 'r') as f:
                file_data = json.load(f)
                
            # 2. Update Current Status from File
            response_data['period'] = file_data.get('period', '---')
            response_data['prediction'] = file_data.get('prediction', 'WAITING')
            response_data['status_text'] = file_data.get('status_text', 'ACTIVE')

            # 3. INTELLIGENT MERGE: Add new items from file to Global History
            # We look at the file's history and add anything we don't have yet.
            new_history_items = file_data.get('history', [])
            
            for new_item in new_history_items:
                # Check if this period exists in our global memory
                existing_item = next((item for item in GLOBAL_HISTORY if item['period'] == new_item['period']), None)
                
                if existing_item:
                    # Update it (e.g., if status changed from PENDING to WIN)
                    existing_item.update(new_item)
                else:
                    # It's new! Add it.
                    GLOBAL_HISTORY.append(new_item)

            # 4. Sort Global History (Oldest first)
            GLOBAL_HISTORY.sort(key=lambda x: int(x['period']))

            # 5. Return the FULL Memory
            response_data['history'] = GLOBAL_HISTORY

    except Exception as e:
        print(f"Error reading data: {e}")
        pass

    return jsonify(response_data)

if __name__ == '__main__':
    print("UI SERVER STARTED ON http://127.0.0.1:5006")
    app.run(debug=True, port=5006)