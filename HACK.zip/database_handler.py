# ==============================================================================
# MODULE: DATABASE_HANDLER.PY
# VERSION: V5.2 (HIGH-SPEED BULK EDITION)
# ==============================================================================
import sqlite3
from typing import List, Dict

DATABASE_FILE = 'ar_lottery_history.db'

def create_connection():
    """Create a database connection to the SQLite database."""
    return sqlite3.connect(DATABASE_FILE)

def setup_database():
    """Create the results tables if they don't exist."""
    conn = create_connection()
    try:
        cursor = conn.cursor()
        # Primary Table for Historical Results
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS results (
                issue TEXT PRIMARY KEY, 
                code INTEGER NOT NULL,
                api_timestamp REAL,
                fetch_timestamp REAL
            )
        """)
        # Secondary Table for Prediction Tracking
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS predictions_v2 (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                predict_for_issue TEXT,
                predicted_label TEXT,
                confidence REAL,
                engine_details TEXT,
                predicted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                actual_label TEXT,
                is_win INTEGER,
                evaluated_at TIMESTAMP,
                data_store_count INTEGER
            )
        """)
        conn.commit()
    except sqlite3.Error as e:
        print(f"[DB ERROR] Setup failed: {e}")
    finally:
        conn.close()

async def save_result_to_database(data_to_save: List[Dict]) -> bool:
    """
    Inserts results using High-Speed Bulk Transactions.
    This is required to handle 10,000+ records efficiently.
    """
    conn = create_connection()
    cursor = conn.cursor()
    new_records_inserted = False
    
    try:
        # Prepare the data batch for fast insertion
        batch = []
        for record in data_to_save:
            batch.append((
                str(record['issue']), 
                int(record['code']), 
                record.get('api_timestamp'), 
                record.get('fetch_timestamp')
            ))
            
        # INSERT OR IGNORE prevents crashes if the issue already exists
        cursor.executemany(
            "INSERT OR IGNORE INTO results (issue, code, api_timestamp, fetch_timestamp) VALUES (?, ?, ?, ?)",
            batch
        )
        
        if cursor.rowcount > 0:
            new_records_inserted = True
            
        conn.commit()
    except sqlite3.Error as e:
        conn.rollback()
        print(f"[DB ERROR] Bulk Save failed: {e}")
        return False
    finally:
        conn.close()
        return new_records_inserted

def ensure_setup():
    setup_database()